"""
A Sample Web-DB Application for DB-DESIGN lecture
Copyright (C) 2022 Yasuhiro Hayashi
"""
DBTYPE   = "postgresql"
HOSTNAME = "127.0.0.1"
PORT     = 5432
DBNAME   = "db-design"
USERNAME = "postgres"
PASSWORD = "c4cf7065b034787b2061088190bf737e"
SHOW_SQL = True
